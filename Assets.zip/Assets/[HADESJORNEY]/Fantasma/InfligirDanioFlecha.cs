using UnityEngine;

public class InfligirDanioFlecha : MonoBehaviour
{
    [Tooltip("1 = medio coraz�n, 2 = un coraz�n, 3 = coraz�n y medio...")]
    public int danioMitadCorazones = 1;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") || other.CompareTag("Ghost") )
            return;

        SistemaVida vida = other.GetComponent<SistemaVida>();
        if (vida != null)
        {
            vida.RecibirDanio(danioMitadCorazones);
        }
    }
}